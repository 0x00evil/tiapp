var win = __ui.createWindow({
    backgroudColor: "white"
});

win.addEventListener("click", function() {
    alert("Hello,world");
});